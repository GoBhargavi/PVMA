from flask import Flask, render_template, request,redirect, url_for, send_from_directory
import sqlite3
from functools import wraps
import json


from datetime import datetime, timedelta, timezone
from flask_jwt_extended import create_access_token
from flask_jwt_extended import get_jwt_identity
from flask_jwt_extended import jwt_required
from flask_jwt_extended import get_jwt
from flask_jwt_extended import set_access_cookies
from flask_jwt_extended import verify_jwt_in_request
from flask_jwt_extended import JWTManager

app = Flask(__name__)


app.config["JWT_SECRET_KEY"] = "super-secret" 
app.config["JWT_TOKEN_LOCATION"] = ["cookies"]
app.config["JWT_COOKIE_CSRF_PROTECT"] = False

jwt = JWTManager(app)

def connect_db():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    # create user table if not exists
    user_table_query = """
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username varchar(255) NOT NULL,
        email varchar(255) NOT NULL UNIQUE,
        password varchar(255) NOT NULL,
        address varchar(255) NOT NULL
        );
    """
    c.execute(user_table_query)
    
    save = conn.commit
    close = conn.close
    return c, save, close


def custom_unauthorized_response(*args):
    return redirect(url_for('login'))

jwt.unauthorized_loader(custom_unauthorized_response)

jwt.expired_token_loader(custom_unauthorized_response)


@app.after_request
def after_request(response):
    # response.headers.add('Access-Control-Allow-Origin', BASE_CORS_URL)
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    response.headers.add('Access-Control-Allow-Credentials', 'true')
    return response

def jwt_or_redirect():
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            verify_jwt_in_request()
            if not get_jwt_identity():
                return redirect(url_for('login'))
            else:
                return fn(*args, **kwargs)
        return decorator
    return wrapper


@app.after_request
def refresh_expiring_jwts(response):
    try:
        exp_timestamp = get_jwt()["exp"]
        now = datetime.now(timezone.utc)
        target_timestamp = datetime.timestamp(now + timedelta(minutes=30))
        if target_timestamp > exp_timestamp:
            access_token = create_access_token(identity=get_jwt_identity()) 
            set_access_cookies(response, access_token)
        return response
    except (RuntimeError, KeyError) as e:
        # Case where there is not a valid JWT. Just return the original response
        return response


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    # if jwt is present in cookies, redirect to dashboard
    if request.cookies.get("access_token_cookie"):
        # verify jwt and redirect to dashboard
        try:
            verify_jwt_in_request()
            return redirect(url_for('dashboard'))
        except:
            pass
    
    if request.method == "GET":
        title = "Login"
        msg = request.args.get('msg')
        if msg:
            return render_template("login.html", title=title,msg=msg)
        return render_template("login.html", title=title)
    
    if request.method == "POST":
        form_data = request.form
        
        user_mail = form_data["email"]
        pwd  = form_data["password"]
        
        cursor, _, close = connect_db() #(cursor, save, close)
        
        query = "SELECT id FROM users WHERE email = ? AND password = ?"
        
        cursor.execute(query, (user_mail, pwd))
        
        result = cursor.fetchone()
        
        if result is None:
            error = "Invalid Credentials. Please try again."
            return redirect(url_for('login',msg=error))
    
    
        user_id = result[0]
        
        close()
        
        response = redirect(url_for('dashboard'))
        expires = timedelta(days=1)
    
        access_token = create_access_token(identity={"email": user_mail,"id": user_id}, expires_delta=expires)
        
        set_access_cookies(response, access_token)
        
        return response

@app.route("/register", methods=["GET", "POST"])
def register():
    try:
        error = None
        # if jwt is present in cookies, redirect to dashboard
        if request.cookies.get("access_token_cookie"):
            # verify jwt and redirect to dashboard
            try:
                verify_jwt_in_request()
                return redirect(url_for('dashboard'))
            except:
                pass
        
        
        if request.method == "POST":
            form_data = request.form
            
            name  = form_data["name"]
            mail = form_data["email"]
            pwd = form_data["password"]
            confirm_pwd = form_data["confirmPassword"]
            
            cursor, save, close = connect_db()
            
            # check if user already exists
            user_check_query = "SELECT id FROM users WHERE email = ?"
            
            cursor.execute(user_check_query, (mail,))
            result = cursor.fetchone()
            
            if result:
                msg = "User already exists"
                return render_template("register.html", msg=msg)
            
            cursor.execute(user_check_query, (mail,))

            if cursor.fetchone():
                error = "User already exists"
                return redirect(url_for('register'), msg=error)
            
            query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)"
            
            cursor.execute(query, (name, mail, pwd))
            
            save()
            close()
            return redirect(url_for('login'))
        
        title = "Register"
        return render_template("register.html", title=title)
    except Exception as e:
        print(e)
        return redirect(url_for('register', msg="Something went wrong"))
        

@app.route("/")
@jwt_or_redirect()
def dashboard():
    # get all cookies
    user = get_jwt_identity()
    user_id = user["id"]
    title = "Dashboard"
    cursor, _, close = connect_db()
    
    
    job_query = "SELECT jobs.id, jobs.job_id, jobs.start_date, jobs.end_date, jobs.status, predictions.title FROM jobs INNER JOIN predictions ON jobs.bucket_id = predictions.data_bucket_id WHERE jobs.user_id = ?"
    
    cursor.execute(job_query, (user_id,))
    
    result = cursor.fetchall()
    
    dict_result = [dict( zip(["id", "job_id","start_date","end_date","status", "title"], row)) for row in result]
    # [{id: 1, "job_id": "sdsd", "2023-03-14", None, "waiting", "title"}, {id: 2, "job_id": "sdsd", "2023-03-14", None, "waiting", "title"}}]
    
    close()
    return render_template("dashboard.html", title=title, predictions=dict_result)

    
@app.route("/new-training")    
@jwt_or_redirect()
def new_training():
    title = "New Training"
    user = get_jwt_identity()
    
    cursor, _, close = connect_db()
    
    
    predictions_query = "SELECT id,data_bucket_id,prediction_id,title FROM predictions WHERE user_id = ?"
    
    cursor.execute(predictions_query, (user["id"],))
    
    result = cursor.fetchall()
    
    dict_result = [
        dict(zip(["id","data_bucket_id", "prediction_id", "title"], row)) for row in result
    ]
    
    return render_template("newTraining.html", title=title, predictions=dict_result)


@app.route("/result")
@jwt_or_redirect()
def detail_page():
    title = "Result Page"
    job_id = request.args.get("job_id")

    cursor, _, close = connect_db()
    
    job_query = f"""
        SELECT start_date, end_date, status, predictions.title FROM jobs
        INNER JOIN predictions ON jobs.bucket_id = predictions.data_bucket_id where jobs.user_id = predictions.user_id and jobs.job_id = '{job_id}'
    """
    cursor.execute(job_query)

    result = cursor.fetchone()
    dict_result  = dict(zip(["start_date", "end_date", "status", "title"], result))
    dict_result["job_id"] = job_id
    close()
    return render_template("result.html", title=title, result= dict_result)


def generate_random_string():
    import string
    import random
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

def generate_prediction_id():
    return "pred_" + generate_random_string()

def generate_train_data_id():
    return "tr_" + generate_random_string()

def generate_job_id():
    return "job_" + generate_random_string()

@app.route("/start-predict", methods=["POST"])
@jwt_or_redirect()
def start_predict():
    form_data = request.form
    user = get_jwt_identity()
    user_id = user["id"]
    cursor, save, close = connect_db()
   
    prediction_id = generate_prediction_id()
    data_bucket_id = generate_train_data_id()
    job_id = generate_job_id()
    
    
    # create a folder in the server to store the data
    # store data in the folder called training_data with the name of the data_bucket_id
    import os
    os.mkdir("training_data/" + data_bucket_id)
    
    climate_data = request.files["climate-data"]
    google_trends_data = request.files["google-trends-data"]
    statistical_data = request.files["statistical-data"]
    
    # save climate data
    with open("training_data/" + data_bucket_id + "/climate_data.csv", "w") as f:
        f.write(climate_data.read().decode("utf-8"))
    
    with open("training_data/" + data_bucket_id + "/google_trends_data.csv", "w") as f:
        f.write(google_trends_data.read().decode("utf-8"))
        
    with open("training_data/" + data_bucket_id + "/statistical_data.csv", "w") as f:
        f.write(statistical_data.read().decode("utf-8"))
    
    
    prediction_query = """
    INSERT INTO predictions (user_id, data_bucket_id, prediction_id, title) VALUES (?, ?, ?, ?)
    """
    
    job_query = """
        INSERT INTO jobs (user_id, job_id,bucket_id, status, start_date, criteria) VALUES (?, ?, ?, ?, ?, ?)
    """
    
    prediction_criteria_start_date = form_data["from-time-prediction"]
    prediction_criteria_end_date = form_data["to-time-prediction"]


    psd = datetime.strptime(prediction_criteria_start_date, "%Y-%m-%d")

    ped = datetime.strptime(prediction_criteria_end_date, "%Y-%m-%d")

    
    
    # get number of months
    months = (ped.month - psd.month)
    start_date = datetime.now()
    cursor.execute(prediction_query, (user_id, data_bucket_id, prediction_id, form_data["title"]))
    
    cursor.execute(job_query, (user_id, job_id, data_bucket_id,"waiting", start_date, str(months)))
    
    save()    
    close()

    return redirect(url_for('dashboard'))

@app.route("/save-data", methods=["POST"])
@jwt_or_redirect()
def save_data():
    form_data = request.form
    user = get_jwt_identity()
    user_id = user["id"]
    cursor, save, close = connect_db()
   
    prediction_id = generate_prediction_id()
    data_bucket_id = generate_train_data_id()
    
    
    # create a folder in the server to store the data
    # store data in the folder called training_data with the name of the data_bucket_id
    import os
    os.mkdir("training_data/" + data_bucket_id)
    
    climate_data = request.files["climate-data"]
    google_trends_data = request.files["google-trends-data"]
    statistical_data = request.files["statistical-data"]
    

    # save climate data
    with open("training_data/" + data_bucket_id + "/climate_data.csv", "w") as f:
        f.write(climate_data.read().decode("utf-8"))
    
    with open("training_data/" + data_bucket_id + "/google_trends_data.csv", "w") as f:
        f.write(google_trends_data.read().decode("utf-8"))
        
    with open("training_data/" + data_bucket_id + "/statistical_data.csv", "w") as f:
        f.write(statistical_data.read().decode("utf-8"))
    
    
    prediction_query = """
    INSERT INTO predictions (user_id, data_bucket_id, prediction_id, title) VALUES (?, ?, ?, ?)
    """

    cursor.execute(prediction_query, (user_id, data_bucket_id, prediction_id, form_data["title"]))
    
    save()
    close()

    return redirect(url_for('new_training'))

@app.route("/predict-saved", methods=["POST"])
def predict_saved():
    form_data = request.form
    prediction_id = form_data["prediction-id"]

    
    cursor, save, close = connect_db()
    job_id = generate_job_id()
    
    job_query = """
        INSERT INTO jobs (user_id, job_id,bucket_id, status, start_date, criteria) VALUES (?, ?, ?, ?, ?, ?)
    """
    
    user_query = """
        SELECT user_id FROM predictions WHERE prediction_id = ?
    """
    
    bucket_query = """
        SELECT data_bucket_id FROM predictions WHERE prediction_id = ?
    """
    
    status = "waiting"
    
    prediction_criteria_start_date = form_data["from-time-prediction"]
    prediction_criteria_end_date = form_data["to-time-prediction"]
    
    # convert to datetime
    psd = datetime.strptime(prediction_criteria_start_date, "%Y-%m-%d")

    ped = datetime.strptime(prediction_criteria_end_date, "%Y-%m-%d")

    
    # get number of months
    months = (ped.month - psd.month)
    
    cursor.execute(user_query, (prediction_id,))
    
    
    user_id = cursor.fetchone()[0]
    
    cursor.execute(bucket_query, (prediction_id,))
    
    bucket_id = cursor.fetchone()[0]
    
    cursor.execute(job_query, (user_id, job_id,bucket_id, status, datetime.now(), str(months)))
    
    save()
    close() 
    return redirect(url_for('dashboard'))


@app.route("/output/<job_id>")
def get_result_img(job_id):
    is_csv = request.args.get("csv")
    if is_csv:
        return send_from_directory("output", job_id + ".csv")
        
    # get images from output folder and show them
    return send_from_directory("output", job_id + ".png")
    

@app.route("/logout")
def logout():
    response = redirect(url_for('login'))
    response.set_cookie("access_token_cookie", expires=0)
    return response

if __name__ == "__main__":
    app.run(debug=True, port = 5001)